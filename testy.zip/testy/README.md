#Pro převedení ifj19 na python3 použijte
cat ./ifj19.py ifjProgram.ifj19 > ifjProgram.py

#Pro spuštění použíjte:
python3 ifjProgram.py
